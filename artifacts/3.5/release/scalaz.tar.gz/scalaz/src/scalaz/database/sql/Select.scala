// Copyright Tony Morris 2008-2009
// This software is released under an open source BSD licence.

// $LastChangedRevision: 169 $
// $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $


package scalaz.database.sql

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait Select {
  def from: From
  def selectors: List[Selector]
  def sql = selectors match {
    case Nil => "*"
    case _ => selectors.map(_.toSQL).mkString(",")
  }

  def where(p: Predicate) = Database.query("SELECT " + sql + " FROM " + from.sql + " WHERE " + p.toSQL)
}

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */  
object Select {
  def select(f: From, s: List[Selector]) = new Select {
    def from = f
    def selectors = s
  }

  implicit def SelectDatabaseResultSet(s: Select) = Database.query("SELECT " + s.sql + " FROM " + s.from.sql)
}
