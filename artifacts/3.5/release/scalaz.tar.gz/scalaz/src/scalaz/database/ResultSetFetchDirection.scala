// Copyright Tony Morris 2008-2009
// This software is released under an open source BSD licence.

// $LastChangedRevision: 169 $
// $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $


package scalaz.database

import java.sql.ResultSet.{FETCH_FORWARD, FETCH_REVERSE, FETCH_UNKNOWN}

/**
 * ResultSet fetch direction.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait ResultSetFetchDirection {
  def asInt: Int
}
/**
 * <code>ResultSet.FETCH_FORWARD</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object Forward extends ResultSetFetchDirection {
  def asInt = FETCH_FORWARD
}
/**
 * <code>ResultSet.FETCH_REVERSE</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object Reverse extends ResultSetFetchDirection {
  def asInt = FETCH_REVERSE
}
/**
 * <code>ResultSet.FETCH_UNKNOWN</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object Unknown extends ResultSetFetchDirection {
  def asInt = FETCH_UNKNOWN
}

/**
 * Functions over ResultSet fetch directions.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
object ResultSetFetchDirection {
  /**
   * All ResultSet fetch direction values.
   */
  def resultSetFetchDirections = List(Forward, Reverse, Unknown)

  /**
   * Returns a ResultSet fetch direction for the given value if one exists.
   */
  def fromInt(n: Int) = resultSetFetchDirections find (_.asInt == n)
}
