// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 33 $
// $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $


package scalaz.database

import java.sql.ResultSet.{ HOLD_CURSORS_OVER_COMMIT, CLOSE_CURSORS_AT_COMMIT }

/**
 * ResultSet holdability.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait ResultSetHoldabilityType {
  def asInt: Int
}
/**
 * <code>ResultSet.HOLD_CURSORS_OVER_COMMIT</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object CursorsOverCommit extends ResultSetHoldabilityType {
  def asInt = HOLD_CURSORS_OVER_COMMIT
}
/**
 * <code>ResultSet.CLOSE_CURSORS_AT_COMMIT</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object CloseCursorsAtCommit extends ResultSetHoldabilityType {
  def asInt = CLOSE_CURSORS_AT_COMMIT
}

/**
 * Functions over ResultSet holdability.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
object ResultSetHoldabilityType {
  /**
   * All ResultSet holdability values.
   */
  def resultSetHoldabilityTypes = List(CursorsOverCommit, CloseCursorsAtCommit)

  /**
   * Returns a ResultSet holdability for the given value if one exists.
   */
  def fromInt(n: Int) = resultSetHoldabilityTypes find (_.asInt == n)
}
