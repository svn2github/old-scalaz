// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 32 $
// $LastChangedDate: 2008-12-09 19:21:18 +1000 (Tue, 09 Dec 2008) $


package scalaz.database.sql

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 32 $<br>
 *          $LastChangedDate: 2008-12-09 19:21:18 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait Selector {
  def toSQL: String
}

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 32 $<br>
 *          $LastChangedDate: 2008-12-09 19:21:18 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */  
object Selector {
  implicit def selector(s: String) = new Selector {
    def toSQL = s
  }
}
