// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 33 $
// $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $


package scalaz.database

import java.sql.ResultSet.{ TYPE_FORWARD_ONLY, TYPE_SCROLL_INSENSITIVE, TYPE_SCROLL_SENSITIVE }

/**
 * ResultSet type.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait ResultSetType {
  def asInt: Int
}
/**
 * <code>ResultSet.TYPE_FORWARD_ONLY</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object ForwardOnly extends ResultSetType {
  def asInt = TYPE_FORWARD_ONLY
}
/**
 * <code>ResultSet.TYPE_SCROLL_INSENSITIVE</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object ScrollInsensitive extends ResultSetType {
  def asInt = TYPE_SCROLL_INSENSITIVE
}
/**
 * <code>ResultSet.TYPE_SCROLL_SENSITIVE</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object ScrollSensitive extends ResultSetType {
  def asInt = TYPE_SCROLL_SENSITIVE
}

/**
 * Functions over ResultSet type.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
object ResultSetType {
  /**
   * All ResultSet type values.
   */
  def resultSetTypes = List(ForwardOnly, ScrollInsensitive, ScrollSensitive)

  /**
   * Returns a ResultSet type for the given value if one exists.
   */
  def fromInt(n: Int) = resultSetTypes find (_.asInt == n)
}
