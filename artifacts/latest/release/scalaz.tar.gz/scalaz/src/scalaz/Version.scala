// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 30 $
// $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $


package scalaz

/**
 * Prints the version of this software.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision<br>
 *          $LastChangedDate<br>
 *          $LastChangedBy: tonymorris $
 */
object Version extends Application {
  println("Scalaz version 3.3")
  println("Compiled against Scala version 2.7.2")
  println("Tested using Reductio version %reductio.version%")
  println("Copyright 2008 Workingmouse Pty. Ltd.")
}
