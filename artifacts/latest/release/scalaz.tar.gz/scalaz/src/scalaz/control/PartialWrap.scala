package scalaz.control

/**
 * Used to partially apply a higher-kinded argument when wrapping control constructs.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
trait PartialWrap[T[_], U[_[_]], V[_[_], _]] {
  /**
   * Completes the application with inference.
   */
  def apply[A](a: T[A])(implicit t: U[T]): V[T, A]
}
