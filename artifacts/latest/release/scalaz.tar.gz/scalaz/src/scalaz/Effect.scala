// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 11930 $
// $LastChangedDate: 2008-07-13 13:42:21 +1000 (Sun, 13 Jul 2008) $


package scalaz

/**
 * A wrapper around a side-effect (<code>scala.Unit</code>)
 *
 * @see scala.Unit
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 11930 $<br>
 *          $LastChangedDate: 2008-07-13 13:42:21 +1000 (Sun, 13 Jul 2008) $<br>
 *          $LastChangedBy: mtony $
 */
sealed trait Effect {
  /**
   * The value of this side-effect.
   */
  def effect: Unit

  /**
   * Executes this side-effect if the given argument is <code>false</code>.
   */
  def unless(c: Boolean) = if(!c) effect

  /**
   * Executes this side-effect if the given argument is <code>true</code>.
   */
  def when(c: Boolean) = if(c) effect
}

/**
 * Functions over side-effects.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 11930 $<br>
 *          $LastChangedDate: 2008-07-13 13:42:21 +1000 (Sun, 13 Jul 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object Effect {
  /**
   * Wraps a <code>scala.Unit</code>.
   */
  implicit def UnitEffect(u: => Unit): Effect = new Effect {
    def effect = u
  }

  /**
   * Unwraps a <code>scala.Unit</code>.
   */
  implicit def EffectUnit(e: Effect) = e.effect
}
