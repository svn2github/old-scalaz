// Copyright Tony Morris 2008-2009
// This software is released under an open source BSD licence.

// $LastChangedRevision: 169 $
// $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $


package scalaz.javas

/**
 * Functions over a <code>java.io.Reader</code>.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
object Reader {
  /**
   * Converts the given <code>Reader</code> to an iterator.
   */
  implicit def ReaderCharIterator(r: java.io.Reader) = new Iterator[Char] {
    var i = r.read

    def next =
      if(i == -1)
        error("Iterator.next (no more elements)")
      else {
        val x = i
        i = r.read
        x.toChar
      }

    def hasNext = i != -1    
  }
}
