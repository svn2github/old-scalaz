// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 30 $
// $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $


package scalaz

/**
 * Wraps an argument of <code>Equal</code> implementations.
 *
 * @see Equal
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait EqualW[A] {
  /**
   * Returns <code>true</code> if this is equal to the given argument, otherwise <code>false</code>.
   */
  def ===(a: A): Boolean

  /**
   * Returns <code>false</code> if this is equal to the given argument, otherwise <code>true</code>.
   */
  def /=(a: A) = !(===(a))
}

/**
 * Functions over equal wrapper values.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
object EqualW {
  /**
   * Constructs an <code>EqualW</code> from the given value and <code>Equal</code> implementation.
   */
  implicit def equal[A](a: A)(implicit e: Equal[A]): EqualW[A] = new EqualW[A] {
    def ===(aa: A) = e.equal(a, aa)
  }
}
