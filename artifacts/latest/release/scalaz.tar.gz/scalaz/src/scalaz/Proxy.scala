// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 12480 $
// $LastChangedDate: 2008-07-31 11:48:07 +1000 (Thu, 31 Jul 2008) $


package scalaz

/**
 * A type-constructor for a lifted value.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12480 $<br>
 *          $LastChangedDate: 2008-07-31 11:48:07 +1000 (Thu, 31 Jul 2008) $<br>
 *          $LastChangedBy: mtony $
 */
sealed trait Proxy[A]

/**
 * Functions over proxies.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12480 $<br>
 *          $LastChangedDate: 2008-07-31 11:48:07 +1000 (Thu, 31 Jul 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object Proxy {
  /**
   * Returns a new proxy. 
   */
  def proxy[A] = new Proxy[A]{}
}
