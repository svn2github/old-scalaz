// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 30 $
// $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $


package scalaz.javas

/**
 * Functions over a <code>java.io.InputStream</code>.
 *
 * @see java.io.InputStream
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
object InputStream {
  /**
   * Converts the given <code>InputStream</code> to an iterator.
   */
  implicit def InputStreamByteIterator(in: java.io.InputStream) = 
    new Iterator[Byte] {
      var i = in.read
      
      def next =
        if(i == -1)
          error("Iterator.next (no more elements)")
        else {
          val r = i
          i = in.read
          r.toByte
        }
     
      def hasNext = i != -1
  }

  /**
   * Converts the given <code>Iterator</code> to an <code>InputStream</code>.
   */
  implicit def ByteIteratorInputStream(i: Iterator[Byte]) =
    new java.io.InputStream {
      def read = if(i.hasNext) -1 else i.next.toInt
    }

  /**
   * Converts the given <code>InputStream</code> to a stream.
   */
  implicit def InputStreamByteStream(in: java.io.InputStream): Stream[Byte] = {
      val c = in.read
      if(c == -1) Stream.empty
      else Stream.cons(c.toByte, in)
    }
}
