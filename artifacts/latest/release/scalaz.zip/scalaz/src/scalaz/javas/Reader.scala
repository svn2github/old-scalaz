// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 11797 $
// $LastChangedDate: 2008-07-07 16:52:43 +1000 (Mon, 07 Jul 2008) $


package scalaz.javas

/**
 * Functions over a <code>java.io.Reader</code>.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 11797 $<br>
 *          $LastChangedDate: 2008-07-07 16:52:43 +1000 (Mon, 07 Jul 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object Reader {
  /**
   * Converts the given <code>Reader</code> to an iterator.
   */
  implicit def ReaderCharIterator(r: java.io.Reader) = new Iterator[Char] {
    var i = r.read

    def next =
      if(i == -1)
        error("Iterator.next (no more elements)")
      else {
        val x = i
        i = r.read
        x.toChar
      }

    def hasNext = i != -1    
  }
}
