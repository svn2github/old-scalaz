package scalaz.control

/**
 * Used to partially apply a higher-kinded argument when wrapping control constructs.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 13568 $<br>
 *          $LastChangedDate: 2008-09-30 06:32:09 +1000 (Tue, 30 Sep 2008) $<br>
 *          $LastChangedBy: mtony $
 */
trait PartialWrap[T[_], U[_[_]], V[_[_], _]] {
  /**
   * Completes the application with inference.
   */
  def apply[A](a: T[A])(implicit t: U[T]): V[T, A]
}
