// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 11769 $
// $LastChangedDate: 2008-07-07 10:31:44 +1000 (Mon, 07 Jul 2008) $


package scalaz

/**
 * Prints the version of this software.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision<br>
 *          $LastChangedDate<br>
 *          $LastChangedBy: mtony $
 */
object Version extends Application {
  println("Scalaz version ${build.number}")
  println("Compiled against Scala version 2.7.2-RC4")
  println("Tested using Reductio version %reductio.version%")
  println("Copyright 2008 Workingmouse Pty. Ltd.")
}
