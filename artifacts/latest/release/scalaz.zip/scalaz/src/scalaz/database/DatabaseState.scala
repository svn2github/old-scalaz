// Copyright Tony Morris 2008-2009
// This software is released under an open source BSD licence.

// $LastChangedRevision: 169 $
// $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $


package scalaz.database

import java.sql.SQLException

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait DatabaseState {
  val con: Connector
  val terminal: Database[Unit]

  def apply[A](db: Database[A]): Either[SQLException, A] =
    con.connect.right.flatMap(c =>
      try {
        c setAutoCommit false
        val a = db(c)
        terminal(c)
        Right(a)
      } catch {
        case e: SQLException => {
          c.rollback
          Left(e)
        }
      } finally {
        c.close
      })
}

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
object DatabaseState {
  def databaseState(c: Connector, t: Database[Unit]) = new DatabaseState {
    val con = c
    val terminal = t
  }

  import Connector._

  def reader(c: Connector): DatabaseState = databaseState(c, Database.rollback)

  def reader(url: String): DatabaseState = reader(driverManager(url))

  def reader(url: String, username: String, password: String): DatabaseState =
    reader(driverManager(url, username, password))

  def writer(c: Connector): DatabaseState = databaseState(c, Database.commit)

  def writer(url: String): DatabaseState = writer(driverManager(url))

  def writer(url: String, username: String, password: String): DatabaseState =
    writer(driverManager(url, username, password))
}
