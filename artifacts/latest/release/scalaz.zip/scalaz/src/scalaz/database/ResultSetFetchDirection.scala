// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 33 $
// $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $


package scalaz.database

import java.sql.ResultSet.{FETCH_FORWARD, FETCH_REVERSE, FETCH_UNKNOWN}

/**
 * ResultSet fetch direction.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait ResultSetFetchDirection {
  def asInt: Int
}
/**
 * <code>ResultSet.FETCH_FORWARD</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object Forward extends ResultSetFetchDirection {
  def asInt = FETCH_FORWARD
}
/**
 * <code>ResultSet.FETCH_REVERSE</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object Reverse extends ResultSetFetchDirection {
  def asInt = FETCH_REVERSE
}
/**
 * <code>ResultSet.FETCH_UNKNOWN</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object Unknown extends ResultSetFetchDirection {
  def asInt = FETCH_UNKNOWN
}

/**
 * Functions over ResultSet fetch directions.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
object ResultSetFetchDirection {
  /**
   * All ResultSet fetch direction values.
   */
  def resultSetFetchDirections = List(Forward, Reverse, Unknown)

  /**
   * Returns a ResultSet fetch direction for the given value if one exists.
   */
  def fromInt(n: Int) = resultSetFetchDirections find (_.asInt == n)
}
