// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 33 $
// $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $


package scalaz.database

import java.sql.ResultSet.{ CONCUR_READ_ONLY, CONCUR_UPDATABLE }

/**
 * ResultSet concurrency.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait ResultSetConcurrencyType {
  def asInt: Int
}
/**
 * <code>ResultSet.CONCUR_READ_ONLY</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object ReadOnly extends ResultSetConcurrencyType {
  def asInt = CONCUR_READ_ONLY
}
/**
 * <code>ResultSet.CONCUR_UPDATABLE</code>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object Updatable extends ResultSetConcurrencyType {
  def asInt = CONCUR_UPDATABLE
}

/**
 * Functions over ResultSet concurrency.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 33 $<br>
 *          $LastChangedDate: 2008-12-09 19:38:21 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
object ResultSetConcurrencyType {
  /**
   * All ResultSet concurrency values.
   */
  def resultSetConcurrencyTypes = List(ReadOnly, Updatable)

  /**
   * Returns a ResultSet concurrency for the given value if one exists.
   */
  def fromInt(n: Int) = resultSetConcurrencyTypes find (_.asInt == n)
}
