// Copyright Tony Morris 2008-2009
// This software is released under an open source BSD licence.

// $LastChangedRevision: 169 $
// $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $


package scalaz.database

import java.sql.ResultSet

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait ResultSetW {
  val resultset: ResultSet

  def ~>[T](f: ImmutableResultSet => T) = new Iterator[T] {
    var h = resultset.next
    def next = {
      val t = f(resultset)
      h = resultset.next
      t
    }
    def hasNext = h
  }
}

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */  
object ResultSetW {
  implicit def resultset(r: ResultSet) = new ResultSetW {
    val resultset = r
  }
}
