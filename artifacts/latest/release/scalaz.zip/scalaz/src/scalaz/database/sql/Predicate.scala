// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 32 $
// $LastChangedDate: 2008-12-09 19:21:18 +1000 (Tue, 09 Dec 2008) $


package scalaz.database.sql

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 32 $<br>
 *          $LastChangedDate: 2008-12-09 19:21:18 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait Predicate {
  def toSQL: String

  import Predicate.predicate

  def |||(p: Predicate) = predicate("(" + toSQL + " OR " + p.toSQL + ")")

  def &&&(p: Predicate) = predicate("(" + toSQL + " AND " + p.toSQL + ")") 
}

/**
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 32 $<br>
 *          $LastChangedDate: 2008-12-09 19:21:18 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */  
object Predicate {
  implicit def predicate(s: String) = new Predicate {
    def toSQL = s
  }
}
