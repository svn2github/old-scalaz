// Copyright Tony Morris 2008-2009
// This software is released under an open source BSD licence.

// $LastChangedRevision: 169 $
// $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $


package scalaz.list

/**
 * Functions over character lists.
 * 
 * @version $LastChangedRevision: 169 $<br>
 *          $LastChangedDate: 2009-03-24 15:09:07 +1000 (Tue, 24 Mar 2009) $<br>
 *          $LastChangedBy: tonymorris $
 */
object CharList {

  implicit def CharListString(cs:List[Char]):String = cs.mkString

  implicit def CharListRichString(cs:List[Char]):runtime.RichString = CharListString(cs)
}
