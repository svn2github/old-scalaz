// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 29 $
// $LastChangedDate: 2008-12-09 19:12:13 +1000 (Tue, 09 Dec 2008) $


package scalaz.list

/**
 * Functions over character lists.
 * 
 * @version $LastChangedRevision: 29 $<br>
 *          $LastChangedDate: 2008-12-09 19:12:13 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
object CharList {

  implicit def CharListString(cs:List[Char]):String = cs.mkString

  implicit def CharListRichString(cs:List[Char]):runtime.RichString = CharListString(cs)
}
