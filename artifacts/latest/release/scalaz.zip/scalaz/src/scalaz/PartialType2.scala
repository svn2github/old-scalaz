// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 12826 $
// $LastChangedDate: 2008-08-18 11:46:21 +1000 (Mon, 18 Aug 2008) $


package scalaz

/**
 * Applies one type argument of two where one of the type arguments has a kind * -> *.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12826 $<br>
 *          $LastChangedDate: 2008-08-18 11:46:21 +1000 (Mon, 18 Aug 2008) $<br>
 *          $LastChangedBy: mtony $
 */
trait PartialType2[T[_[_], _], A[_]] {
  type Apply[B] = T[A, B]
}
