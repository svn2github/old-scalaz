// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 30 $
// $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $


package scalaz

/**
 * Applies one type argument of two. This is used for taking a type constructor of kind <code>* -> * -> *</code> to
 * <code>* -> *</code> by partially applying one type argument. The <code>Apply</code> type applies the first argument
 * and the <code>Flip</code> type applies the second argument. See also
 * <a href="https://lampsvn.epfl.ch/trac/scala/ticket/339">Ticket #339</a>.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
trait PartialType[T[_, _], A] {
  type Apply[B] = T[A, B]

  type Flip[B] = T[B, A]
}
