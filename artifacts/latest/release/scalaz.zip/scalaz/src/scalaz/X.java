package scalaz;

public final class X {
  private X() {
    throw new UnsupportedOperationException();
  }
}
