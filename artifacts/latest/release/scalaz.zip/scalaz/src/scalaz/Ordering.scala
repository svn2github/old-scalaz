// Copyright Tony Morris 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 30 $
// $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $


package scalaz

/**
 * An ordering of 'less than', 'equal to' or 'greater than'.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
sealed trait Ordering {
  /**
   * An integer representation of this ordering.
   */
  val toInt: Int
}

/**
 * An ordering of 'less than'.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object LT extends Ordering {
  /**
   * <code>-1</code>.
   */
  val toInt = -1
}

/**
 * An ordering of 'equal to'.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object EQ extends Ordering {
  /**
   * <code>0</code>.
   */
  val toInt = 0
}

/**
 * An ordering of 'greater than'.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
final case object GT extends Ordering {
  /**
   * <code>1</code>.
   */
  val toInt = 1
}

import control.Monoid

/**
 * Functions over ordering.
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version $LastChangedRevision: 30 $<br>
 *          $LastChangedDate: 2008-12-09 19:15:58 +1000 (Tue, 09 Dec 2008) $<br>
 *          $LastChangedBy: tonymorris $
 */
object Ordering {
  /**
   * Constructs an ordering from the given integer value
   * <pre>
   * n < 0 => LT
   * n == 0 => EQ
   * n > 0 => GT  
   * </pre>
   */
  implicit def fromInt(n: Int) =
    if(n < 0) LT
    else if(n == 0) EQ
    else GT

  /**
   * A monoid for ordering where <code>EQ</code> is identity. 
   */
  implicit val OrderingMonoid = new Monoid[Ordering] {
    val zero = EQ
    def append(x: => Ordering, y: => Ordering) = if(x == EQ) y else x
  }
}
