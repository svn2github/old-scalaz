import scalaz.control._

final object T {
  
  def main(args: Array[String]) {

  }
}
