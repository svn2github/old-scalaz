// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 12388 $
// $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $


package scalaz

/**
 * An ordering of 'less than', 'equal to' or 'greater than'.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12388 $<br>
 *          $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $<br>
 *          $LastChangedBy: build $
 */
sealed trait Ordering {
  /**
   * An integer representation of this ordering.
   */
  val toInt: Int
}

/**
 * An ordering of 'less than'.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12388 $<br>
 *          $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $<br>
 *          $LastChangedBy: build $
 */
final case object LT extends Ordering {
  /**
   * <code>-1</code>.
   */
  val toInt = -1
}

/**
 * An ordering of 'equal to'.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12388 $<br>
 *          $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $<br>
 *          $LastChangedBy: build $
 */
final case object EQ extends Ordering {
  /**
   * <code>0</code>.
   */
  val toInt = 0
}

/**
 * An ordering of 'greater than'.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12388 $<br>
 *          $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $<br>
 *          $LastChangedBy: build $
 */
final case object GT extends Ordering {
  /**
   * <code>1</code>.
   */
  val toInt = 1
}

/**
 * Functions over ordering.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12388 $<br>
 *          $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $<br>
 *          $LastChangedBy: build $
 */
object Ordering {
  /**
   * Constructs an ordering from the given integer value
   * <pre>
   * n < 0 => LT
   * n == 0 => EQ
   * n > 0 => GT  
   * </pre>
   */
  implicit def fromInt(n: Int) =
    if(n < 0) LT
    else if(n == 0) EQ
    else GT
}
