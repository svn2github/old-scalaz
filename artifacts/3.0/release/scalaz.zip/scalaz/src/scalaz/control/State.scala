// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 12388 $
// $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $


package scalaz.control

/**
 * Stateful computation.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12388 $<br>
 *          $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $<br>
 *          $LastChangedBy: build $
 */
sealed trait State[S, A] {
  /**
   * Perform the computation and pass the state through.
   */
  def state(s: S): (S, A)
}

/**
 * Functions over state.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12388 $<br>
 *          $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $<br>
 *          $LastChangedBy: build $
 */
object State {
  /**
   * Constructs a state from the given state-passing function.
   */
  def state[S, A](f: S => (S, A)) = new State[S, A] {
    def state(s: S) = f(s)
  }
}
