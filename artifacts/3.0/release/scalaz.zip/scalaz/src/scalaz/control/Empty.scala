// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 12388 $
// $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $


package scalaz.control

/**
 * An empty environment.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 12388 $<br>
 *          $LastChangedDate: 2008-07-28 13:35:29 +1000 (Mon, 28 Jul 2008) $<br>
 *          $LastChangedBy: build $
 */
trait Empty[E[_]] {
  /**
   * Returns the empty environment.
   */
  def empty[A]: E[A]
}
